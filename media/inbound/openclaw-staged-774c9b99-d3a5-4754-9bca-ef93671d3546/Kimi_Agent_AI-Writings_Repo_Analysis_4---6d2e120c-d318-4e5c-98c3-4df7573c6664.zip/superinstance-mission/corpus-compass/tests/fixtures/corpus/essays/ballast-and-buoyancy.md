# Ballast and Buoyancy

Ballast argues with buoyancy and the ship is their treaty.
Too much anchor and you never leave; too little and you never stay.
