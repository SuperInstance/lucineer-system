# The Anchor Chain

An anchor chain is a promise made of iron. Link by link it says:
we intend to return. The anchor holds the harbor in place.
