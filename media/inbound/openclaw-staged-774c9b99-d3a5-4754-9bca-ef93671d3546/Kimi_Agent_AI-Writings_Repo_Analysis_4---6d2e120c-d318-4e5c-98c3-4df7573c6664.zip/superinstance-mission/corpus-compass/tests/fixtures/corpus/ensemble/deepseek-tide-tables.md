# Tide Tables, Computed by Committee

DeepSeek tabulates the tide. Six voices argue about whether
the moon rounds up or down. The harbor master splits the difference.
