# The Guardrail Riff

GLM riffs on guardrails: every guardrail is a tide line someone
drew and then the sea negotiated.
