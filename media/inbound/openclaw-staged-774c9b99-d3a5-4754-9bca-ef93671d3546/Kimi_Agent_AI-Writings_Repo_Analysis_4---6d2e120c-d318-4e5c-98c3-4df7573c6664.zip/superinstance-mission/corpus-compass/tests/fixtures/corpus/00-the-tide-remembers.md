# The Tide Remembers

The tide keeps its own ledger. Every hull that leaves the harbor
is written down in salt, and the tide remembers each departure.
