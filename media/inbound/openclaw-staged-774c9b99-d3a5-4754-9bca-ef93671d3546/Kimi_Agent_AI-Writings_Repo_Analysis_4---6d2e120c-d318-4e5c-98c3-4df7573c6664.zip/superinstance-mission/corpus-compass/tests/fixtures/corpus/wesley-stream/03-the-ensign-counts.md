# The Ensign Counts the Stars

Wesley counts stars from the night watch, one by one, the way
a tide counts pebbles. The stars do not mind being counted.
