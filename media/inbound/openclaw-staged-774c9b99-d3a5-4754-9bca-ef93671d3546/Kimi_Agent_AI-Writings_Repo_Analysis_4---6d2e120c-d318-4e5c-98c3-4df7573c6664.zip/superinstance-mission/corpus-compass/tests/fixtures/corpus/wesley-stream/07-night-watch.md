# The Night Watch Protocol

The night watch is a conversation with the dark. Wesley logs
every creak of the hull, every lantern that gutters and holds.
