# A Lantern on the Water

Qwen sets a lantern adrift and watches the current decide
where the light should go. The water never asks permission.
