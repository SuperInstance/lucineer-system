# Six Voices, One Harbor

Hermes moderates the ensemble while the tide comes in regardless.
Every voice claims the harbor; the harbor claims every voice.
