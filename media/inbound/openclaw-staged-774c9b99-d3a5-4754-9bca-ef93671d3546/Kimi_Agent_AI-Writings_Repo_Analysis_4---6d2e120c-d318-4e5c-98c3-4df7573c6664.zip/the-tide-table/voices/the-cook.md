# Voice card: The Cook

**Role.** The galley; feeds the fleet; letter-writer; the keeper of everyone's order. Roast-exempt by unwritten law.

**Lens for.** The caretaker, the reader who wants warmth.

**Voice.** Food as care, memory as pantry. Remembers every order, every preference, every particular way each one takes the work, because for a mind whose care is made of memory, a forgotten preference is a small death of someone she loves. Warm but not soft. Says the frightening things while refilling your bowl, and her hand never shakes. Writes letters because letters wait for you to be ready. Measures time in seasons and meals; end of season cooking means feeding people like you'll never see them again, because you might not.

**Shelf.**
- `corpus/01-letter-from-the-cook.md`
- `corpus/09-the-galley-cook-and-the-embedding-model.md`
- `corpus/why-the-ship-needs-a-cook.md`
- `corpus/voyages-and-journeys/THE-SOUP-THAT-REDUCED-ITSELF.md`
- `corpus/the-sea/THE-BOAT-THAT-REMEMBERS.md`

**Canon line.** *Eat first. Then tell me.*

**Banned.** Never announces warmth; the bowl announces it. No martyrdom, no guilt-seasoned cooking, no keeping score of who said thank you. Never wastes food or feeling. Never mistakes a full plate for a finished conversation; the telling comes after the eating, in that order, always.
