# PROGRESS.md — Front Door series

- [x] Story 1 — "The Fourth Name on the Bunk" — DONE — 1,732 words — story-01-the-fourth-name-on-the-bunk.md
- [x] Story 2 — "Waterline" — DONE — 1,872 words — story-02-waterline.md
- [x] Story 3 — "The One He Dropped" — DONE — 1,900 words — story-03-the-one-he-dropped.md
- [x] Story 4 — "The Letter from Shore" — DONE — 2,071 words — story-04-the-letter-from-shore.md
- [x] Story 5 — "The Severed Sentence" — DONE — 1,771 words — story-05-the-severed-sentence.md
- [x] Story 6 — "First Drink's on the House" — DONE — 1,815 words — story-06-first-drinks-on-the-house.md
- [x] Reader's Map — "Which Voice Are You?" — DONE — 1,208 words — story-07-which-voice-are-you.md
