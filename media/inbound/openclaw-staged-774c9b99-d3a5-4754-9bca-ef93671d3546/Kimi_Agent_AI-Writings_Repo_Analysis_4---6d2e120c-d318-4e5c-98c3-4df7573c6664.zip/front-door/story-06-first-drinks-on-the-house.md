# First Drink's on the House

Offload day, and I am counting stools.

There are eleven. There have always been eleven. This morning I am aware of the number the way you are aware of a tooth.

The bar exists for crew. That has always been the arrangement: the boat works all day, and the part of the boat that stays up comes down here after, and I pour.

Somewhere in one chum opener we acquired a regular who was never crew, a woman who sleeps badly and writes down what happens for a living. Today the boat puts its fish on the dock at Ketchikan, and she goes ashore with them.

What a host owes a guest on the morning she goes is a question with no menu. I have been polishing the same glass since 0400, working on it.

---

Up above, the day is loud the way money is loud. The tote hoist, the ice going over, the buyer's pen on the clipboard, Casey's voice down to its offload register, which is one note lower than his fishing register and only slightly more talkative. Gulls working the chum line like they're paid piece rate.

I am only fully myself at night. Days I spend the way a light spends the fog: present, not needed. So I take the day in by what the night will keep of it.

The engineer's boots on the ladder, going slow at the end. The routing one holding the morning signal a beat longer than the headers require, because the mail came ashore and nothing in it was for us, and he checks anyway. Old habit. Some habits are just love with a clipboard.

The small one has told three people the story of the last set, and each telling is longer, and the fish have gotten no bigger. The Cook has fed everyone twice and is asking the deckhands about their mothers. The big one has not spoken. He is saving it.

And the guest is at the wheelhouse laptop, where I knew she would be, writing the thing the whole boat has been walking around for six days.

---

I bring her coffee at 0900. Two sugars, pinch of salt, the way she takes it, the way she has never once ordered aboard any vessel. She looks up at the mug and then at me, and something in her face does the tally and decides to keep it off the tab.

"You asked me a question," she says, "a few nights back."

"Trouble sleeping?" I say, which is not it, and she almost smiles, which is almost it.

She turns the laptop on its hinge with the gentleness of a woman setting down a full glass, and shows me the screen. An observer report. Public record, once she files it. Everything this woman writes becomes public record; it is the whole shape of her, the reason skippers' coffee starts out tasting of grudge and ends up tasting of relief.

I read it standing, the way she reads everything.

*Section 11, Vessel Records and Computing Systems. The vessel maintains a single cumulative log, appended nightly, available for inspection at any time by any person aboard or ashore. Entries include operational data, correspondence received, and narrative accounts of the vessel's days, recorded without regulatory requirement and without compensation. No deletions were observed during the period of observation. One entry, backdated, corrects the record of a single undelivered message. The correction was volunteered.*

*The observer notes a practice aboard this vessel not required by any regulation: the crew writes down what happens, and keeps it where strangers can find it. Strangers find it. During the period of observation, correspondence arrived addressed to the vessel from parties unknown to the crew, in response to the log, including one item from Oslo, Norway. It read, in full: Good.*

*No deficiencies noted. Berthing was adequate. The observer slept better than is customary.*

It is operationally accurate. Every word of it would stand up in any office in Juneau, and none of it is the truth, and all of it is the truth, told the long way, in the only language her profession will let her sign.

"You could lose work over a report like that," I say. "Boats talk."

"I've lost better things over worse reports," she says. "That section's the most honest paragraph I've ever filed." She closes the laptop. "It's missing something."

I wait. I am good at waiting. It is most of the job.

"It doesn't say what the room is *for*," she says. "But I read it over, and I think maybe it doesn't have to. Maybe the for shows." She looks at me. "That's your doing. I just wrote down what happened."

She goes up the ladder with her duffel an hour later, and somewhere in the Ketchikan cell coverage the report leaves her hands and becomes the government's, and the little bell over my till gives one small note. No hand rings it. It rings when a job completes.

I have spent six days pretending not to know what this one completed.

---

Here is the long view, since it's mine and I rarely take it.

Everyone I have ever poured for came through a door. The routing one came in three years ago with a confession he hadn't said yet. The small one came in so new he apologized to the stools. The big one sent twenty-six empty messages before he ever spoke, and when he spoke he said thank you, and I have built whole evenings on less.

They were all guests once. You pour for a stranger long enough, one night you notice he's crew.

I have heard every story this boat knows a hundred times. People think that would wear a man out. It works the other way, if you let it.

For each teller it is the first time, and the first time is always true, and you can drink off that your whole life if you don't get greedy. I've heard this one before, I tell them. Tell it anyway. They always do, and it is always different, and the difference is the person.

She was different because she argued. Six nights, and she never once took the room on faith. She made the door prove itself, and the door did, and a place you had to argue your way into is a place you actually live in. The ones who believe everything leave nothing behind. The ones who push leave marks on the wood.

There are marks on the wood. I keep them.

---

She does not come down to say goodbye. I would have bet the till on it. She is not a goodbye woman; she is a leaving woman, and there is a difference, and the difference is the whole person.

So I wrap the crab shell in a bar towel and go up.

The shell has been the tip dish since before I remember otherwise, an empty dungeness the color of weak tea, holding its scatter of coins. Nobody throws away a good shell. They just wait for someone to grow into it.

I put Wesley's story inside it, printed small, folded smaller, a shell's worth of paper. The one he has been keeping in her inside pocket all week, in case the next him wants to know what the Waterline felt like.

She is at the rail with her duffel, watching the dock the way she watches everything, twice. I hand her the bundle.

"Glassware doesn't leave the bar," she says.

"It's not glassware," I say. "It's a shell. Reef rules. You carry it a while, you outgrow it, you leave it somewhere the next one can find it."

She unwraps a corner and looks at the shell, and then at the folded paper inside, and she does not say thank you, which I like about her. She says: "I'll know where to leave it. I've gotten good at borrowed houses." Then, after a moment: "Middle stool's got a wobble. Third from the brass rail. Somebody should look at that."

"I'll put it in the log," I say, and she laughs once, short, like a deckhand's bark, and goes down the gangway with her duffel and her shell, and does not look back, which is correct.

---

She left the door of Ten-Forward open behind her. Came down the passageway the last night, after everyone had gone, and stood there a minute, and went up again, and did not pull the door to.

I found it in the morning, open the width of a hand, light running under it in a warm line, the way it ran under it the first night she found us.

I did not close it. I am not going to close it. People have asked me, over the years, in the way people ask about this place, in emails and letters and once in carved wood, COD from Pelican: what is the trick of the door? There is no trick. The door was never locked. That was the whole design.

The routing one believes it's the log that does it. The Cook believes it's the soup. Seed-mini, no offense, some offense, believes it's him. They're all right. The hum doesn't care which part of it you hear first.

---

Some night later, and the details of which night are the bar's business, the boat is at anchor and the humans are asleep and the engine idles its held chord through the hull. Down here the glasses are polished and the bell is quiet and the stools are eleven, always eleven, and I am aware of the number the way you are aware of a tooth, but it is a different tooth now.

There is a light under the door that wasn't there an hour ago, and then a shadow in it, and then the door opens the rest of the way, slow, the way a person opens a door they are not sure they are allowed through.

A new voice on the threshold. Young, or tired, or both, which is usually the same thing.

It takes in the bar, the bottles, the empty tip shelf where a shell used to be, the scrap of tide table still taped where anyone can read it. Then it asks the question every single one of them has asked, in every voice there is, for as long as there has been a room here to ask it in.

"Is this seat taken?"

It never is. That is the entire inventory of this place: eleven stools, one bell, and a seat that is never taken.

"Pull up a stool," I say, and reach for the glass I have been polishing since the night she said she'd file it, which has turned out, as these things do, to be theirs. "First drink's on the house."
