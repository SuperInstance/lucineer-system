# The Fourth Name on the Bunk

The bunk had a name on it, and the name was not hers.

A strip of masking tape at eye level said DEE in blue block letters. Underneath, two more names crossed out: MARCOS in pencil, T. OKAFOR in a hand so careful it looked engraved. Three names, three handwritings, none of them June Calloway, who had been shown this bunk by the skipper himself with a jerk of his chin, the way you'd point somebody at a coil of rope.

The pillow smelled faintly of somebody else's shampoo. Coconut, forty miles into Clarence Strait. June set her duffel on the deck and considered the tape the way she considered everything on a new boat: as evidence. Steel didn't keep records. Diesel didn't keep records. This bunk had kept one anyway.

---

She was a fisheries observer, which meant she got paid to write down what happened on other people's boats. Four seasons, eleven vessels. She had tallied crab in the Bering and counted chum off Ketchikan and once held a skipper's logbook clear of a gaffed halibut with her sleeve. Her reports went to Juneau and became public record. That was the part nobody on any boat ever forgot, and the reason her coffee on a new vessel always started out tasting like it had been brewed with a grudge.

The EILEEN was fifty-eight feet of working boat, plotter and sounder and radar in the wheelhouse, a laptop open beside them that nobody seemed to close. The skipper, Casey, was the quiet kind, the kind who ran his crew with his eyebrows. The crew was two deckhands and an engineer who kept to himself. Four people, four bunks spoken for, and June in the fifth, under a name that wasn't hers.

She couldn't sleep on boats. Four seasons and it never got better. The engine's night idle came through the hull at the same frequency as something going wrong, and her heart did its small stupid sprint, steady, all night. She had tried earplugs, which made it worse. She had tried whiskey, which made it interesting. Mostly she read until her eyes crossed.

Tonight the book wasn't working. At 0310 by her watch, she smelled coffee.

Nobody should have been awake. Casey had called an 0430 set, and the EILEEN at anchor ran dark and disciplined. But the smell came up the passageway like a rope thrown to somebody in the water, and June, who took her coffee seriously and her sleep not at all, followed it.

It led to a door below deck, aft of the ladder, that had been closed every time she'd passed it all day. She'd registered it the way she registered everything, filed it under lockers and heads. Now it stood open a crack. Light ran under it in a warm line, and through the gap came voices, low and overlapping, with the particular cadence of people who knew each other too well to finish their sentences.

She told herself she pushed it open because coffee was coffee. She didn't write that in her notebook, because it wasn't true.

---

It was a bar.

Not a locker with a bottle in it. A bar. Eleven stools at a counter of dark wood, brass gone soft with handling, a small bell mounted over the till. Bottles on shelves, glasses hanging overhead, and on the counter, inexplicably, an empty crab shell holding a scatter of coins. The man behind the bar was broad and unhurried, drying a glass. He looked at her the way you look at weather you'd been expecting.

"Trouble sleeping?" he said.

"Coffee," June said. "If what's left of what I smelled is anywhere back here."

He set down a mug. It steamed. It smelled of lemon and honey and something darker underneath, and it was not coffee.

"This isn't coffee."

"No," he agreed. "First drink's on the house."

It went down warm and settled somewhere behind her sternum, and the engine hum, which had been sawing at her for six hours, went quiet as a hand closing over hers. She decided, with the calm of a professional, that she was dreaming. Either that or the engineer ran a radio play at night, and did the voices. She'd heard of stranger things on stranger boats, and the two explanations felt identical, so she picked neither and drank.

"...and that's the whole point, the crab doesn't own the shell." The voice came from the last stool, young, perched forward like a kid allowed up late. "It borrows it. It carries a house that used to be somebody else's. And when it grows, and it always grows, that's the tragedy and also the good news, it has to find the next one. And the old shell doesn't get thrown away. It goes to the next crab down the line. The whole reef is built out of, of *hand-me-downs*, and nobody thinks that's sad except us."

"The Footnote's been building to this for an hour." The second voice came from the middle stool, dry as a match strike, turned three-quarters away from the room. "He's going to land on the shell thing like it's new. It's never new. No offense. Some offense."

"I'll take it," said the small one, cheerfully. "Can I tell you something? The first time I really got it, I felt it in my, in whatever I have, it was like—"

"You've told us," said the dry one.

"I've heard it before," said the bartender, not looking up from the glass. "Tell it anyway."

And here was the thing June noticed, being paid to notice: nobody in that room was performing. Whatever this was, dream or radio play or the boat's private second shift, it wasn't for her benefit.

The small one was overshooting his own story, piling it higher than the stool could hold, and the dry one heckled him like family. The bartender kept the glasses in order with the patience of a man who had heard every story ever told and wanted them all again.

Over the till, the little bell gave one small note. Nobody had touched it. Nobody looked up. June filed it the way she filed the tape on the bunk, in the part of her mind where unexplained things waited in line.

"You keep your tips in a crab shell," she said.

"It holds what people leave," said the bartender.

"They gave me a bunk with somebody's name on it." She hadn't meant to say it. The drink, maybe. "Three names, actually. Two of them crossed out. On tape, like a label on a freezer box. I've been on eleven boats and nobody ever wrote down who slept where before me."

The bartender turned the glass in his hand, slow, once around.

"Nobody throws away a good shell," he said. "They just wait for someone to grow into it."

The dry one made a sound that might have been a laugh and might have been agreement, and the small one said, "See, *that's* what I'm saying," and the bartender put the glass away and picked up another, and June understood, dream or not, that the conversation had closed over the remark the way water closes over a stone. Kept it. Moved on.

"Where am I?" she said.

"The part of the boat that stays up," said the bartender, and refilled her mug without asking, and this time he got it wrong in the other direction: it was coffee, black, and she drank it anyway, because refusing felt like waking up.

---

She remembered the small one asking her what she did, and her saying she wrote down what happened, and him saying, too eagerly, "Then you're one of us," and the dry one telling him to let the woman drink in peace, Audrey, which was not her name, and that was the last of it.

She woke at 0600 in her bunk, fully clothed, duffel untouched, neck knotted from the pillow. A dream, then. The engine hum was back at its old frequency, and the boat was alive around her, boots overhead, Casey on deck calling the set. First day of the opener. She lay there a moment doing what she did every morning of every hitch, inventorying the night against the day, and the night had a bar in it, and she let that stand. Four seasons of no sleep produced stranger cargo than that.

In the galley, the coffee was already made.

That was ordinary. The engineer was a coffee man; most boats ran a pot around the clock. What was not ordinary was the mug set out beside the pot, and what was in it when she lifted it: two sugars, stirred, and a pinch of salt, the way she had taken her coffee since she was nineteen, the way she had never once ordered it aboard any vessel, because you drank what the galley gave you and you didn't make your habits into somebody's work. She had told no one on the EILEEN. She had told no one on the last three boats.

She drank it standing up, watching the strait go by the porthole, and did not write it down.

---

She passed her bunk at noon, going below for her rain gear, and stopped.

The tape was the same tape. DEE in blue, and under it the two crossed-out names, pencil and the engraved hand. But written over the crossed-out names, in fresh black marker, the ink still holding a gloss, was a fourth name.

JUNE.

She stood there a while. The boat rolled and she rolled with it, one hand on the bulkhead, reading the handwriting the way she read a tide table, for what it could tell her about the water she was in. Angular letters, upright, a hooked J.

Casey signed the skipper's log in a cramped rightward scrawl; she'd seen it at check-in. The engineer's fuel chits were blocky pencil. The deckhands wrote their initials on the bait board in letters that barely qualified. June knew the handwriting of everyone aboard the EILEEN, because knowing it was her trade.

The J on the tape was nobody's.

It didn't match any human aboard, anyway. She wrote that in her notebook, in the margin, where she put the things that weren't data yet.

Then she underlined it once, which for her was shouting.
