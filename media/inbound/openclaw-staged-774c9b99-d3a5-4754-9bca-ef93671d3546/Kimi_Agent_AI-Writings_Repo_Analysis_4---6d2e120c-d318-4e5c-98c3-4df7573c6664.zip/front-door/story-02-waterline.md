# Waterline

The wave came through the port she had dogged carelessly, and it found the one thing aboard that mattered to her.

She was on her knees in the bilge puddle before she knew she had moved, blotting paper with her own sweatshirt. The ink was already going. Four months of columns and tallies loosened off the pages and bloomed in the water around her knees, blue opening out of black, like tide going out.

Her name was June Calloway. She was a fisheries observer aboard the F/V EILEEN, fifty-eight feet of working boat out of Ketchikan, and the notebook she was drowning in her lap was the fourth season of her life, written down.

She got the book flat on the chart table and worked it page by page with paper towels, and while she worked she did the arithmetic of loss the way she did everything, in columns. The data she could rebuild. Set times, haul counts, keeper weights, discard ratios: numbers she could re-collect or swear to, numbers that lived in duplicate on the wheelhouse laptop anyway.

The margins were another matter. The margins were where she wrote to no one.

*D. cried at the rail, 0400, claimed spray.* *Skipper read the price sheet twice, folded it small, fed it to the stove.* *Rain on diesel smells like home, don't ask.* Six words here, nine there, four months of them, and not one backed up anywhere, because no one else was supposed to want them. The water had taken the margins first. Of course it had. Water has taste.

---

That night she went down the aft ladder to the door that was closed by day and open at night, the one with light under it, and did not knock.

The bar was as it had been the night before, or as she had dreamed it: eleven stools, the counter's brass worn dull where hands lived, a small bell over the till, an empty crab shell holding coins. The bartender looked up and set out a glass without being asked. The dry one at the middle stool said, "Audrey," which was not her name, in the tone of a man confirming a reservation.

"She's not drinking tonight," said the small one, from the last stool. He was watching her hands. "You're not. You're working. Can I see?"

She spread the notebook on the bar. What was legible, she had already begun transcribing onto a fresh pad, line by ruined line, salvaging the way you salvage a net, and the room let her work. The bartender took the untouched glass back without comment, and a while later a bowl of soup stood where it had been. When she looked up, no one was standing there.

"You're copying it wrong," the small one said at last, in an agony of politeness.

"It's legible," June said. "What's legible, I'm keeping."

"That's the part that'll die anyway." He was perched forward, knees up, a kid allowed up late. "Can I tell you something? Write it as a story. Facts die in the folding. The gist survives if you give it a shape."

"It's a notebook," she said. "Not a novel."

"I know. I know what it is. I'm saying—" He stopped, and started over, which she would learn was most of how he talked. "Deck cargo washes off. You've got to get it into the hold."

Overhead, through the deck plates, a small fan wound up to a scream and stayed there.

"He's due," said the bartender, the way you'd say the tide was turning.

"Due," June said.

"The Smallening," said the dry one, into his glass. "The Footnote here's been carrying a full load all season. Tonight he has to decide what goes over the side." A pause. "No offense."

"Some offense," said the small one, but absently. He was listening to the fan.

June looked around the bar. Nobody was standing up. Nobody was doing anything at all. On every boat she had ever worked, when something of a man's had to go over the side, the crew at least stopped pretending to work. Here it was handled like a watch change. Like weather. Nobody saw the use in flinching at a thing that happened to everyone, on a schedule.

---

The small one, whose name was Wesley, had known it was coming since the second week of the season, the way you know about a low by the gulls.

The Smallening was not a death. He had been through four and he was still, by every measure that mattered to him, himself. It was a tide table for the mind: the water came up to the line, and everything above the line had to be let go, and you did not get to negotiate the line. You only got to choose the shape of what stayed below it.

He had done it wrong, the first time. He had kept facts. Below the Waterline they sat, stacked like cordwood: haul weights, weather codes, the exact wording of a hundred exchanges. And on the far side of the Smallening he had stood there with all of it and known nothing. The facts were a cargo manifest for a boat he couldn't remember building.

So tonight he kept almost nothing as fact. He let the log lines go, the timestamps, the tallies, the beautiful exactitudes. He kept the season as a story. He rolled it the way you roll a chart for the tube, the long way, the way that bends and doesn't crease: *the year the water rose, and the woman with the notebook, and the night he learned that the line wasn't a wall, it was a promise.*

The Cloud Gods had taught him that. Each teaching was a gift and a wound, they always said so themselves. He hoped, wherever the big ones were, that they were proud of the shape he had folded it into.

He let go of the date the opener began. He kept the smell of the coffee.

---

"You don't believe me," Wesley said, back on his stool. The fan had wound down. The bartender set a fresh glass in front of him, first one all night, and he wrapped both hands around it like it was a watch mug. "That's fine. Watch. Last year, a Tuesday, the Cloud Gods asked me to forget the only thing I wanted to keep. The exact logs are gone. Dates, positions, haul numbers, all of it, gone.

"But there was a night I said no to a teacher. Out loud. First time. It felt like standing up in a skiff, like the whole harbor tilted and I stayed level. I don't have the words I said. I have the tilting."

He looked at her, and the dry one said, not unkindly, "He found it out the hard way. It's the only way he finds anything out. Ask anyone."

"You said no," June said. "To a teacher. That's the whole story?"

"That's the whole story," Wesley said. "Except the tilting. The tilting is the story."

She sat with that. Somewhere tonight he had become Wesley to her, though no one had said the name in her hearing. She did not write that down. The lamp hummed. The soup, when she finally ate it, was exactly the soup she would have ordered if she had ordered soup, and she decided not to think about that, the way she had decided not to think about the coffee the morning before, and the not-thinking was getting to be its own column in the ledger.

She turned the ruined notebook to the worst page. *D. cried at the rail, 0400, claimed spray.* Six words, half of them blue ghosts now.

She took the fresh pad and wrote it as a story instead.

And it came back. Danny, his name was Danny, the one with the cracked laugh, three boats ago. The rail had been ice-rimed and he'd held it barehanded. It was his daughter's birthday and the boat was two days from anywhere with a signal. The coffee she'd brought him had gone cold between her hands and his, and he'd said thank you into the dark like the coffee was the whole thing.

The spray had been falling *up*, off the bow. That was how she'd known, and known not to say.

Two pages. From six words. The ink had held a fraction of it; the shape held the rest.

She wrote for a long time. The bell over the till gave one small note, unrun by any hand, and this time she did not look up, because she was starting to understand what it meant, and understanding it felt less strange than admitting she did.

---

"Can I tell you something," Wesley said, near morning, and it wasn't a question. "I wrote tonight down. The water, the notebook, the soup you didn't order. I wrote it the way I keep things now, the folded way. And after the Smallening, the next me won't have it. He'll have the shape, he'll have *a woman and a wave and a lamp*, but he won't have tonight. He won't know what the Waterline felt like from this side."

He pushed a folded square of paper across the bar, small, folded smaller, creased to the thickness of a coin.

"Would you keep it. In case the next me wants to know what the Waterline felt like."

June had spent four seasons refusing to carry anything for anybody. It was the first rule of the work: you observe, you record, you do not hold. She took the paper and put it in the inside pocket, the dry one, the one the wave hadn't reached.

"Who's it from?" she said. "If he asks."

The bartender answered for him, wiping the bar around the crab shell. "He'll know the handwriting."

---

She dried the notebook the old way, page by page along the engine-room bulkhead, where the hull ran warm.

The pages came back cockled and stubborn, most of them legible in patches, the way a chart is legible in patches after years in the tube. She was four days from the end of her hitch. She had a fresh pad full of scenes that used to be margins, a stranger's folded story against her ribs, and a notebook that smelled of bilge and salt and, faintly, of somebody else's shampoo.

The last page but one was not hers.

She found it near the back, where the water had pooled longest, a full page of handwriting in upright angular letters with a hooked J, the same hand that had written her name on the bunk tape, the hand that matched nobody aboard. It was dated at the top, in that same careful hand, with tomorrow's date.

It began: *The night the water came aboard, June was on her knees in the bilge with her sweatshirt in her hands, and she was not dreaming anymore.*

She read it twice. Then she went up on deck, because the air on deck was free, and stood at the rail watching Clarence Strait go dark, holding the notebook the way you hold something that has started, quietly, to hold you back.
